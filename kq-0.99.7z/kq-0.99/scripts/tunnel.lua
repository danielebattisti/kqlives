-- tunnel - "The tunnel leading to Esteria"

function autoexec()
  return
end


function entity_handler(en)
  return
end


function postexec()
  return
end
