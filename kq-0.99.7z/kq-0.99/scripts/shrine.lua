-- shrine - "The water shrine, with the tunnel that leads to Esteria"

function autoexec()
  return
end


function entity_handler(en)
  return
end


function postexec()
  return
end
