/* Allegro datafile object indexes, produced by grabber v4.2.0 (beta4), MinGW32 */
/* Datafile: kq/data/mpcx.dat */
/* Date: Sun Nov 05 21:20:48 2006 */
/* Do not hand edit! */

#define ALLFONTS_PCX                     0        /* BMP  */
#define BACK10_PCX                       1        /* BMP  */
#define BACK11_PCX                       2        /* BMP  */
#define BACK1_PCX                        3        /* BMP  */
#define BACK2_PCX                        4        /* BMP  */
#define BACK3_PCX                        5        /* BMP  */
#define BACK4_PCX                        6        /* BMP  */
#define BACK5_PCX                        7        /* BMP  */
#define BACK6_PCX                        8        /* BMP  */
#define BACK7_PCX                        9        /* BMP  */
#define BACK8_PCX                        10       /* BMP  */
#define BACK9_PCX                        11       /* BMP  */
#define CASTLE_PCX                       12       /* BMP  */
#define DESTITLE_PCX                     13       /* BMP  */
#define ENEMY_PCX                        14       /* BMP  */
#define ENTITIES_PCX                     15       /* BMP  */
#define FORTRESS_PCX                     16       /* BMP  */
#define INCAVE_PCX                       17       /* BMP  */
#define KQFACES_PCX                      18       /* BMP  */
#define KQT_PCX                          19       /* BMP  */
#define LAND_PCX                         20       /* BMP  */
#define LFLAME_PCX                       21       /* BMP  */
#define MISC_PCX                         22       /* BMP  */
#define MOUNT_PCX                        23       /* BMP  */
#define NEWTOWN_PCX                      24       /* BMP  */
#define TITLE_PCX                        25       /* BMP  */
#define USBAT_PCX                        26       /* BMP  */
#define USCHRS_PCX                       27       /* BMP  */
#define VILLAGE_PCX                      28       /* BMP  */
#define X_KQ_PAL                         29       /* PAL  */

