/* Allegro datafile object indexes, produced by grabber v4.0.2, Unix */
/* Datafile: /home/peter/prog/KQ/data/kqsnd.dat */
/* Date: Sat Dec 14 18:07:33 2002 */
/* Do not hand edit! */

#define ARROW_WAV                        0        /* SAMP */
#define BAD_WAV                          1        /* SAMP */
#define BLACK_WAV                        2        /* SAMP */
#define BLIND_WAV                        3        /* SAMP */
#define BMAGIC_WAV                       4        /* SAMP */
#define BOLT1_WAV                        5        /* SAMP */
#define BOLT2_WAV                        6        /* SAMP */
#define BOLT3_WAV                        7        /* SAMP */
#define BUYSELL_WAV                      8        /* SAMP */
#define CHOP_WAV                         9        /* SAMP */
#define CONFUSE_WAV                      10       /* SAMP */
#define CURE_WAV                         11       /* SAMP */
#define DEEQUIP_WAV                      12       /* SAMP */
#define DISPEL_WAV                       13       /* SAMP */
#define DOOM_WAV                         14       /* SAMP */
#define DOOR2_WAV                        15       /* SAMP */
#define DOOROPEN_WAV                     16       /* SAMP */
#define DRAIN_WAV                        17       /* SAMP */
#define EQUIP_WAV                        18       /* SAMP */
#define EXPLODE_WAV                      19       /* SAMP */
#define FLAME_WAV                        20       /* SAMP */
#define FLOOD_WAV                        21       /* SAMP */
#define GAS_WAV                          22       /* SAMP */
#define HIT_WAV                          23       /* SAMP */
#define HURT_WAV                         24       /* SAMP */
#define ICE_WAV                          25       /* SAMP */
#define INN_WAV                          26       /* SAMP */
#define ITEM_WAV                         27       /* SAMP */
#define KILL_WAV                         28       /* SAMP */
#define MENUMOVE_WAV                     29       /* SAMP */
#define POISON_WAV                       30       /* SAMP */
#define QUAKE_WAV                        31       /* SAMP */
#define RECOVER_WAV                      32       /* SAMP */
#define SCORCH_WAV                       33       /* SAMP */
#define SHIELD_WAV                       34       /* SAMP */
#define SLASH_WAV                        35       /* SAMP */
#define STAB_WAV                         36       /* SAMP */
#define STAIRS_WAV                       37       /* SAMP */
#define TELEPORT_WAV                     38       /* SAMP */
#define TWINKLE_WAV                      39       /* SAMP */
#define WHITE_WAV                        40       /* SAMP */
#define WHOOSH_WAV                       41       /* SAMP */
#define WIND_WAV                         42       /* SAMP */

